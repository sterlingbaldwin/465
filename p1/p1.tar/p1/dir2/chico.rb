line 1 of chico.rb chico california

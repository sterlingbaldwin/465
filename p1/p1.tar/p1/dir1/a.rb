line 1 of a.arb  chico california





line 7 of a.arb  chico california

line 1 of c.js chico california
  line 2 of c.js chico california (indented 2 spaces)
   line 3 of c.js chico california (indented 3 spaces)
    line 4 of c.js chico california (indented 4 spaces)
     line 5 of c.js chico california (indented 5 spaces)
